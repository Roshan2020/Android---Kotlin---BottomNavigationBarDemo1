package com.example.bottomnavigationbardemo1.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.renderscript.ScriptGroup.Binding
import android.view.MenuItem
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.viewbinding.ViewBinding
import com.example.bottomnavigationbardemo1.R
import com.example.bottomnavigationbardemo1.databinding.ActivityMainBinding
import com.example.bottomnavigationbardemo1.fragment.Firstpg
import com.example.bottomnavigationbardemo1.fragment.Secondpg
import com.example.bottomnavigationbardemo1.fragment.Thirdpg

class MainActivity : AppCompatActivity() {
    var binding: ActivityMainBinding? = null
    var firstpg = Firstpg()
    var secondpg = Secondpg()
    var thirdpg = Thirdpg()
    lateinit var drawerLayout: DrawerLayout
    lateinit var actionBarDrawerToggle: ActionBarDrawerToggle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        currentPg(firstpg)
        binding!!.bottomNavBar.setOnNavigationItemSelectedListener {
            when(it.itemId){
                R.id.tab_home -> currentPg(firstpg)
                R.id.tab_profile -> currentPg(secondpg)
                R.id.tab_settings -> currentPg(thirdpg)
            }
            true
        }
        drawerLayout = findViewById(R.id.my_drawer_layout)
        actionBarDrawerToggle = ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close)
        drawerLayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    fun currentPg(fragment: Fragment) {
        var ft = supportFragmentManager.beginTransaction()
        ft.replace(R.id.fl_page, fragment)
        ft.commit()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            true
        } else super.onOptionsItemSelected(item)
    }
}